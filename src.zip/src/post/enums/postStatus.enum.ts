export enum PostStatus {
  DRAFT = 'draft',
  SCHEDULE = 'schedule',
  REVIEW = 'review',
  PUBLISHED = 'published',
}
