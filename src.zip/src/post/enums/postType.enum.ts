export enum PostType {
  STORY = 'story',
  POST = 'post',
  PAGE = 'page',
  SERIES = 'series',
}
